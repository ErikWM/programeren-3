//Erik Wansink Manglano
// Nummer: 1033805
package com.company;

public class ContainerWarm extends Container {
    @Override
    public void losKoppelen(){
        System.out.println("word uit verwarmingselement gehaald");
    }
    public void vastKoppelen(){
        System.out.println(" koel verwarmingselementmelement word toegevoegd");
    }
    public ContainerWarm(){
        super();


    }


}
